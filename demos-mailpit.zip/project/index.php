<?php

echo "Hello from Docker !!";